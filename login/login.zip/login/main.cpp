#include <iostream>
#include <string>
#include <windows.h>
#include <mysql.h>

using namespace std;

int main()
{
     MYSQL* connection;
     MYSQL_ROW row;
     MYSQL_RES *res;

     connection = mysql_init(0);

     if(connection)
        cout<<"connection successful "<<endl;
     else
        cout<<"connection problem: "<<mysql_error(connection)<<endl;

    connection = mysql_real_connect(connection,"localhost","root","","customer",0,NULL,0);

    if(connection){
        cout<<"Connected"<<connection<<endl;

        string username,password;
        cout<<"enter username: "<<endl; cin>>username;
        cout<<"enter password: "<<endl; cin>>password;

        string query="select * from information where username='"+username+"' and password='"+password+"';";

        int queryResult = mysql_query(connection, query.c_str());
        MYSQL_RES* result = mysql_store_result(connection);

        if (mysql_num_rows(result) >= 1)
        {
            cout<<"Welcome to the game"<<endl;
        }
        else{
            cout<<"Please try again"<<endl;
        }


    }


}
