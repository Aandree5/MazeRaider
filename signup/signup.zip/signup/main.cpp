#include <iostream>
#include <string>
#include <windows.h>
#include <mysql.h>

using namespace std;

int main()
{
     MYSQL* connection;
     MYSQL_ROW row;
     MYSQL_RES *res;
     int qstate;

     connection = mysql_init(0);

     if(connection)
        cout<<"connection successful "<<endl;
     else
        cout<<"connection problem: "<<mysql_error(connection)<<endl;

    connection = mysql_real_connect(connection,"localhost","root","","customer",0,NULL,0);

    if(connection){
        cout<<"Connected"<<connection<<endl;

        string name,username,password;
        cout<<"enter username: "<<endl; cin>>name;
        cout<<"enter name: "<<endl; cin>>username;
        cout<<"enter password: "<<endl; cin>>password;


        string query="insert into information(name,username,password) values('"+name+"','"+username+"','"+password+"')";


        const char* q = query.c_str();

        qstate = mysql_query(connection,q);

        if(!qstate)
            cout<<"Register successful"<<endl;
        else
            cout<<"Sorry try it again "<<mysql_error(connection)<<endl;
    }


}
